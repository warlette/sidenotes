// SideNotes Content Script - Safe page details reader

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'GET_PAGE_CONTEXT') {
    const selectedText = window.getSelection() ? window.getSelection().toString().trim() : '';
    const pageTitle = document.title || 'Untitled Page';
    const pageUrl = window.location.href;
    const metaDesc = document.querySelector('meta[name="description"]')?.content || '';

    sendResponse({
      title: pageTitle,
      url: pageUrl,
      selectedText: selectedText,
      description: metaDesc
    });
  }
  return true;
});
